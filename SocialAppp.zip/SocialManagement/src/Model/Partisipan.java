/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author DELL
 */
public class Partisipan {

    /**
     * @return the namaU
     */
    public String getNamaU() {
        return namaU;
    }

    /**
     * @param namaU the namaU to set
     */
    public void setNamaU(String namaU) {
        this.namaU = namaU;
    }

    /**
     * @return the partisipasiid
     */
    public Integer getPartisipasiid() {
        return partisipasiid;
    }

    /**
     * @param partisipasiid the partisipasiid to set
     */
    public void setPartisipasiid(Integer partisipasiid) {
        this.partisipasiid = partisipasiid;
    }

    /**
     * @return the eventid
     */
    public Integer getEventid() {
        return eventid;
    }

    /**
     * @param eventid the eventid to set
     */
    public void setEventid(Integer eventid) {
        this.eventid = eventid;
    }
    private Integer partisipasiid;
    private String namaU;
    private Integer eventid;
}
